# Todo-List-App
## [Watch it on youtube](https://youtu.be/u_ocJEv6c4Q)
### Building a Todo List App from Scratch | HTML, CSS, JavaScript 

💙 Join the channel to see more videos like this. [Open Source Coding](https://www.youtube.com/@opensourcecoding)

![preview img](/preview.png)
